exports.config = {
    jwtSecret: "smartApp"
};
